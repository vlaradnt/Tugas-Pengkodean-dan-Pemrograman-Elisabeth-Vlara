-- database.sql
CREATE DATABASE bakery_inventory;
USE bakery_inventory;

-- Table for raw materials
CREATE TABLE materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL, -- Diubah dari ENUM ke VARCHAR agar bisa input manual
    unit VARCHAR(20) NOT NULL, -- Diubah dari ENUM ke VARCHAR agar bisa input manual
    stock_quantity DECIMAL(10, 2) NOT NULL DEFAULT 0,
    expiration_date DATE,
    supplier_id INT,
    purchase_price DECIMAL(10, 2)
);

-- Table for suppliers
CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact VARCHAR(100)
);

-- Table for stock transactions (in/out)
CREATE TABLE stock_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    material_id INT,
    quantity DECIMAL(10, 2) NOT NULL,
    transaction_type ENUM('in', 'out') NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Insert some sample suppliers
INSERT INTO suppliers (name, contact) VALUES
('Supplier A', 'supplierA@example.com'),
('Supplier B', 'supplierB@example.com');