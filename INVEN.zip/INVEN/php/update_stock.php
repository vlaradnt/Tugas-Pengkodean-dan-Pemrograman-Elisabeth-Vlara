<?php
// php/update_stock.php
header('Content-Type: application/json');
include 'config.php';

$data = json_decode(file_get_contents('php://input'), true);
$materialId = $data['materialId'];
$quantity = $data['quantity'];
$type = $data['type'];

// Start a transaction
$pdo->beginTransaction();

try {
    // Insert transaction record
    $stmt = $pdo->prepare("INSERT INTO stock_transactions (material_id, quantity, transaction_type) VALUES (?, ?, ?)");
    $stmt->execute([$materialId, $quantity, $type]);

    // Update stock quantity
    $operator = $type === 'in' ? '+' : '-';
    $stmt = $pdo->prepare("UPDATE materials SET stock_quantity = stock_quantity $operator ? WHERE id = ?");
    $stmt->execute([$quantity, $materialId]);

    $pdo->commit();
    echo json_encode(['status' => 'success']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>