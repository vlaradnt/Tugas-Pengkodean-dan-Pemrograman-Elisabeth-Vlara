<?php
// php/get_materials.php
header('Content-Type: application/json');
include 'config.php';

if (isset($_GET['suppliers'])) {
    $stmt = $pdo->query("SELECT * FROM suppliers");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} else {
    $stmt = $pdo->query("SELECT m.*, s.name AS supplier_name FROM materials m LEFT JOIN suppliers s ON m.supplier_id = s.id");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}
?>