// js/script.js
document.addEventListener('DOMContentLoaded', () => {
    fetchSuppliers();
    fetchMaterials();

    // Handle form submission for adding materials
    document.getElementById('addMaterialForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const material = {
            name: document.getElementById('materialName').value,
            category: document.getElementById('category').value,
            unit: document.getElementById('unit').value,
            purchasePrice: document.getElementById('purchasePrice').value,
            expirationDate: document.getElementById('expirationDate').value,
            supplierId: document.getElementById('supplier').value
        };

        await fetch('php/add_material.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(material)
        });
        fetchMaterials(); // Refresh the table
        e.target.reset();
    });
});

// Fetch suppliers for the dropdown
async function fetchSuppliers() {
    const response = await fetch('php/get_materials.php?suppliers=true');
    const suppliers = await response.json();
    const supplierSelect = document.getElementById('supplier');
    suppliers.forEach(supplier => {
        const option = document.createElement('option');
        option.value = supplier.id;
        option.textContent = supplier.name;
        supplierSelect.appendChild(option);
    });
}

// Fetch materials and display them in the table
async function fetchMaterials() {
    const response = await fetch('php/get_materials.php');
    const materials = await response.json();
    const tbody = document.querySelector('#materialTable tbody');
    tbody.innerHTML = '';

    materials.forEach(material => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${material.name}</td>
            <td>${material.category}</td>
            <td>${material.unit}</td>
            <td>${material.stock_quantity}</td>
            <td>${material.expiration_date}</td>
            <td>${material.supplier_name}</td>
            <td>${material.purchase_price}</td>
            <td>
                <button onclick="updateStock(${material.id}, 'in')">Stock In</button>
                <button onclick="updateStock(${material.id}, 'out')">Stock Out</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Update stock (in/out)
async function updateStock(materialId, type) {
    const quantity = prompt(`Enter quantity to ${type === 'in' ? 'add' : 'remove'}:`);
    if (quantity && !isNaN(quantity)) {
        await fetch('php/update_stock.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ materialId, quantity: parseFloat(quantity), type })
        });
        fetchMaterials(); // Refresh the table
    }
}