let produkList = [];

function tambahProduk() {
    let nama = document.getElementById("namaProduk").value;
    let stok = parseInt(document.getElementById("stokProduk").value);
    let harga = parseInt(document.getElementById("hargaProduk").value);

    if (nama && stok > 0 && harga > 0) {
        produkList.push({ nama, stok, harga });
        tampilkanProduk();
    } else {
        alert("Masukkan data dengan benar!");
    }
}

function tampilkanProduk() {
    let daftarProduk = document.getElementById("daftarProduk");
    daftarProduk.innerHTML = "";

    produkList.forEach((produk, index) => {
        daftarProduk.innerHTML += `
            <tr>
                <td>${produk.nama}</td>
                <td>${produk.stok}</td>
                <td>Rp ${produk.harga}</td>
                <td><button onclick="hapusProduk(${index})">Hapus</button></td>
            </tr>
        `;
    });
}

function hapusProduk(index) {
    produkList.splice(index, 1);
    tampilkanProduk();
}

function jualProduk() {
    let nama = document.getElementById("produkTerjual").value;
    let jumlah = parseInt(document.getElementById("jumlahTerjual").value);

    let produk = produkList.find(p => p.nama.toLowerCase() === nama.toLowerCase());

    if (produk) {
        if (produk.stok >= jumlah && jumlah > 0) {
            produk.stok -= jumlah;
            tampilkanProduk();
            alert("Penjualan berhasil!");
        } else {
            alert("Stok tidak cukup atau jumlah tidak valid!");
        }
    } else {
        alert("Produk tidak ditemukan!");
    }
}
